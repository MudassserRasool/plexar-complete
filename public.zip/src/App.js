import './App.css';
// import ClindexHomePage from './Plexar-Other-Projects/plexar-home-page/src/App'
// import AccountingMannagement from './Plexar-Other-Projects/plexar-accounting-and-finance/src/App'
// import HrMannagement from './Plexar-Other-Projects//plexar-Hr-Mannagement/src/App'
// import InveentoryMannagement from './Plexar-Other-Projects/plexar-inventory-management/src/App'
import OndelProject from './Plexar-Other-Projects/plexar-ondel/src/App'



function App() {
  return (
    <div>
      {/* <ClindexHomePage/> */}
      {/* <AccountingMannagement/> */}
      {/* <HrMannagement/> */}
      {/* <InveentoryMannagement/> */}
      <OndelProject/>
    </div>
  );
}

export default App;
