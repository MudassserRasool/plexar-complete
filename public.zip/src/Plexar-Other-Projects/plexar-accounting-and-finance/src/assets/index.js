import PlexarLogo from "./PlexarLogo.png";
import UserAccountIcon from "./UserAccountIcon.png";
import WomanImageForHeroSection from "./WomanImageForHeroSection.png";
import WomanImageForHeroSectionSmallScreen from "./WomanImageForHeroSectionForSmallerSceen.png";
import MannagementGroupWorkingImgae from "./MannagementGroupWorkingImgae.png";
import AiBookingIcon from "./AiBookingIcon.png";
import AnimatedStatisticsMobileImage from "./AnimatedStatisticsMobileImage.png";
import CalendexWorkingImage from "./CalendexWorkingImage.png";
import MarkitingAnimatedPcImage from "./MarkitingAnimatedPcImage.png";
import AiPowerAutomationIcon from "./AiPowerAutomationIcon.png";
import FeaturesOrderTextArrowIcon from "./FeaturesOrderTextArrowIcon.png";
import AiScheduler from "./AiScheduler.png";
import NewslatterSendButtonIcon from "./NewslatterSendButtonIcon.png";
import PlexaarFooterLogo from "./PlexaarFooterLogo.png";
import MoneyMapingIcon from "./MoneyMapingIcon.png";
import CashControlIcon from "./CashControlIcon.png";
import MoneyInfoIcon from "./MoneyInfoIcon.png";
export {
  PlexarLogo,
  UserAccountIcon,
  WomanImageForHeroSection,
  WomanImageForHeroSectionSmallScreen,
  MannagementGroupWorkingImgae,
  AiBookingIcon,
  AnimatedStatisticsMobileImage,
  CalendexWorkingImage,
  MarkitingAnimatedPcImage,
  AiPowerAutomationIcon,
  FeaturesOrderTextArrowIcon,
  AiScheduler,
  NewslatterSendButtonIcon,
  PlexaarFooterLogo,
  MoneyMapingIcon,
  CashControlIcon,
  MoneyInfoIcon,
};
