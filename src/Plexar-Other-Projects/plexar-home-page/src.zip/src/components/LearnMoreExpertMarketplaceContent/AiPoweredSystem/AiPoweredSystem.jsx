import React from "react";
import "./AiPoweredSystem.css";
import {
  AiBookingIcon,
  AiPowerAutomationIcon,
  AiScheduler,
  AnimatedStatisticsMobileImage,
} from "..//..//../assets/index";
import { Link } from "react-router-dom";

const AiPoweredSystem = () => {
  return (
    <div className="aiPoweredSectionMarginTop px-2 px-md-0">
      <div className="aiPoweredSystemContainer container">
        <div className="d-md-flex justify-content-between align-items-center">
          {/* start left text section---------------------------- */}
          <div className="col-md-5">
            <h1 className="aiPoweredStystemHeading">
              <span className="aiPoweredHeadingLatter">Customer </span>Messaging
            </h1>
            <p className="aiPoweredPara">
            Communicate directly with customers through the Expert Marketplace messaging system, addressing any inquiries or providing assistance. 
            </p>
            {/* start ai powered items-------------------- */}
            <div className="d-grid aiItemsGrid">
              {/* start ai powered item-------------------- */}
              <div className="d-flex gap-4 ">
                <img src={AiScheduler} alt="" className="AiItemIcon" />
                <div className="aiItemNameAndPara">
                  <h1 className="aiItemNameText">Social Selling</h1>
                  <p className="aiParaText">
                  Sell directly through Instagram and Facebook platforms with a simple tap, expanding your reach and boosting sales effortlessly.
                  </p>
                </div>
              </div>
              {/* start ai powered item-------------------- */}
              {/* start ai powered item-------------------- */}
              <div className="d-flex gap-4 ">
                <img
                  src={AiPowerAutomationIcon}
                  alt=""
                  className="AiItemIcon"
                />
                <div className="aiItemNameAndPara">
                  <h1 className="aiItemNameText">Business Management</h1>
                  <p className="aiParaText">
                  Manage your entire business operations from one centralized platform, saving time and effort while ensuring smooth operations.
                  </p>
                </div>
              </div>
              {/* start ai powered item-------------------- */}
              {/* start ai powered item-------------------- */}
              <div className="d-flex gap-4 ">
                <img src={AiBookingIcon} alt="" className="AiItemIcon" />
                <div className="aiItemNameAndPara">
                  <h1 className="aiItemNameText">Custom Campaign Design</h1>
                  <p className="aiParaText">
                  Need more specific campaigns? Get the flexibility to request custom campaign designs from graphic designers, tailored to your unique business needs.
                  </p>
                </div>
              </div>
              {/* end ai powered item-------------------- */}
              <div className="d-flex justify-content-center  justify-content-md-start">
              <Link
                  className="text-decoration-none"
                  to={"/learn-more-digital-records-sub-page"}
                  onClick={() => window.scrollTo(0, 0)}
                >
                  <div className="learnButtonButtonBoxForAiPoweredItemsSection ">
                    <p className="text-center pt-3 learnButtonCoustomText">
                      Learn More
                    </p>
                  </div>
                </Link>
              </div>
              
            </div>
            {/* end ai powered items-------------------- */}
          </div>
          {/* end left text section---------------------------- */}

          {/* start right text section---------------------------- */}
          <div className="col-md-5 mt-4 mt-md-0">
            <img
              src={AnimatedStatisticsMobileImage}
              alt=""
              width={531}
              height={480}
              className="img-fluid"
            />
          </div>
          {/* end right text section---------------------------- */}
        </div>
      </div>
    </div>
  );
};

export default AiPoweredSystem;
