import PlexarLogo from "./PlexarLogo.png";
import UserAccountIcon from "./UserAccountIcon.png";
import WomanImageForHeroSection from "./WomanImageForHeroSection.png";
import WomanImageForHeroSectionMobileVersion from "./WomanImageForHeroSectionMobileVersion.png";
import MannagementGroupWorkingImgae from "./MannagementGroupWorkingImgae.png";
import AiBookingIcon from "./AiBookingIcon.png";
import AnimatedStatisticsMobileImage from "./AnimatedStatisticsMobileImage.png";
import CalendexWorkingImage from "./CalendexWorkingImage.png";
import AiPowerAutomationIcon from "./AiPowerAutomationIcon.png";
import FeaturesOrderTextArrowIcon from "./FeaturesOrderTextArrowIcon.png";
import AiScheduler from "./AiScheduler.png";
import NewslatterSendButtonIcon from "./NewslatterSendButtonIcon.png";
import PlexaarFooterLogo from "./PlexaarFooterLogo.png";
import MoneyMapingIcon from "./MoneyMapingIcon.png";
import CashControlIcon from "./CashControlIcon.png";
import MoneyInfoIcon from "./MoneyInfoIcon.png";
import ContactUsAnimation from './ContactUsAnimation.png'
import HrResponsibilitiesGirlImage from './HrResponsibilitiesGirlImage.png'
export {
  PlexarLogo,
  UserAccountIcon,
  WomanImageForHeroSection,
  WomanImageForHeroSectionMobileVersion,
  MannagementGroupWorkingImgae,
  AiBookingIcon,
  AnimatedStatisticsMobileImage,
  CalendexWorkingImage,
  AiPowerAutomationIcon,
  FeaturesOrderTextArrowIcon,
  AiScheduler,
  NewslatterSendButtonIcon,
  PlexaarFooterLogo,
  MoneyMapingIcon,
  CashControlIcon,
  MoneyInfoIcon,
  ContactUsAnimation,
  HrResponsibilitiesGirlImage,
};
